﻿$ErrorActionPreference = "Continue"

$Base = Join-Path $env:LOCALAPPDATA "K666VideoDownloaderAgent"
$TaskName = "K666 Video Downloader Agent"
$StartupRegPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$StartupRegName = "K666 Video Downloader Agent"

function Info($Message) {
  Write-Host ""
  Write-Host $Message
}

Info "Uninstalling local downloader agent..."
Info "This removes the local agent, startup task, token, settings and cache. Downloaded files will not be deleted."

try {
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
} catch {}
try {
  Remove-ItemProperty -Path $StartupRegPath -Name $StartupRegName -ErrorAction SilentlyContinue
} catch {}

try {
  Get-CimInstance Win32_Process |
    Where-Object { $_.CommandLine -like "*local_agent.server*" -or $_.CommandLine -like "*run-agent.ps1*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}

if (Test-Path $Base) {
  Remove-Item $Base -Recurse -Force -ErrorAction SilentlyContinue
}

try {
  Invoke-RestMethod -Uri "http://127.0.0.1:17890/api/health" -TimeoutSec 2 | Out-Null
  Info "The local agent is still running. Please restart Windows and try again."
} catch {
  Info "The local agent has been uninstalled. Run 01-INSTALL again when needed."
}

Read-Host "Press Enter to close"
