#!/bin/bash
set -euo pipefail

APP_NAME="VideoDownloaderAgent"
BASE="$HOME/Library/Application Support/$APP_NAME"
APP_DIR="$BASE/app"
VENV="$BASE/.venv"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
UPDATER="$SCRIPT_DIR/_internal/updater.py"
if [ ! -f "$UPDATER" ]; then
  UPDATER="$APP_DIR/local_agent/updater.py"
fi
CONTROL_URL="http://127.0.0.1:17890/"
MANIFEST_URL="https://download.k666.xyz/downloads/update.json"

info() {
  printf "\n%s\n" "$1"
}

finish() {
  printf "\n更新窗口可以关闭了。\n"
  printf "如果浏览器没有自动打开，请访问：%s\n" "$CONTROL_URL"
  read -r -n 1 -s -p "按任意键关闭..." || true
  printf "\n"
}
trap finish EXIT

info "正在更新本地下载助手..."
if [ ! -x "$VENV/bin/python" ] || [ ! -d "$APP_DIR" ]; then
  info "未检测到已安装的本地助手，请先运行 01-INSTALL。"
  exit 1
fi
if [ ! -f "$UPDATER" ]; then
  info "更新组件缺失，请重新下载安装包。"
  exit 1
fi

"$VENV/bin/python" "$UPDATER" --app-dir "$APP_DIR" --manifest-url "$MANIFEST_URL" --restart
info "更新命令已完成，正在打开本机控制台..."
open "$CONTROL_URL?updated=$(date +%s)"
