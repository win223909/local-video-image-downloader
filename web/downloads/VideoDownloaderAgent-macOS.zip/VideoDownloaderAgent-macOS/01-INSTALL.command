        #!/bin/bash
        set -euo pipefail

        APP_NAME="VideoDownloaderAgent"
        BASE="$HOME/Library/Application Support/$APP_NAME"
        APP_DIR="$BASE/app"
        VENV="$BASE/.venv"
        LOG_DIR="$BASE/logs"
        TOOLS_DIR="$BASE/tools"
        FFMPEG_DIR="$TOOLS_DIR/ffmpeg"
        FFMPEG_BIN="$FFMPEG_DIR/bin"
        ZIP_PATH="$BASE/agent-source.zip"
        SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
        BUNDLED_ZIP="$SCRIPT_DIR/_internal/agent-source.zip"
        if [ ! -f "$BUNDLED_ZIP" ]; then
          BUNDLED_ZIP="$SCRIPT_DIR/agent-source.zip"
        fi
        PLIST="$HOME/Library/LaunchAgents/app.video-downloader.agent.plist"
        AGENT_URL="https://download.k666.xyz/downloads/agent-source.zip"
        UPDATE_MANIFEST_URL="https://download.k666.xyz/downloads/update.json"
        ALLOWED_ORIGIN="https://download.k666.xyz"
        CONTROL_URL="http://127.0.0.1:17890/"
        EXPECTED_SHA256="0291e88a0c40b538fc05e34472ca03bd80d63777e0323163bff1dbd4e56a7b44"
        PYTHON_VERSION="3.12.10"
        PYTHON_MIN_VERSION="3.9"
        PYTHON_PKG_URL="https://www.python.org/ftp/python/3.12.10/python-3.12.10-macos11.pkg"
        FFMPEG_ZIP_URL="https://evermeet.cx/ffmpeg/getrelease/zip"
        FFPROBE_ZIP_URL="https://evermeet.cx/ffmpeg/getrelease/ffprobe/zip"
        PIP_INDEX_URLS="${PIP_INDEX_URLS:-${PIP_INDEX_URL:-https://pypi.org/simple} https://mirrors.aliyun.com/pypi/simple https://pypi.tuna.tsinghua.edu.cn/simple https://pypi.doubanio.com/simple}"
        PLAYWRIGHT_DOWNLOAD_HOSTS="${PLAYWRIGHT_DOWNLOAD_HOSTS:-${PLAYWRIGHT_DOWNLOAD_HOST:-} https://npmmirror.com/mirrors/playwright}"

        info() {
          printf "\n%s\n" "$1"
        }

        python_ok() {
          "$1" - <<'PY' >/dev/null 2>&1
import sys
import venv
raise SystemExit(0 if sys.version_info >= (3, 9) else 1)
PY
        }

        find_python() {
          for candidate in \
            "/opt/homebrew/bin/python3" \
            "/usr/local/bin/python3" \
            "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3" \
            "/Library/Frameworks/Python.framework/Versions/3.12/bin/python3" \
            "/Library/Frameworks/Python.framework/Versions/3.11/bin/python3" \
            "/usr/bin/python3" \
            "$(command -v python3 2>/dev/null || true)"
          do
            [ -z "$candidate" ] && continue
            [ ! -x "$candidate" ] && continue
            if python_ok "$candidate"; then
              printf "%s\n" "$candidate"
              return 0
            fi
          done
          return 1
        }

        install_python_dependency() {
          info "未检测到可用的 Python 3.9+，正在尝试自动安装 Python..."
          mkdir -p "$BASE"
          if command -v brew >/dev/null 2>&1; then
            info "正在使用 Homebrew 安装 Python..."
            brew install python@3.12 || brew install python || true
            PYTHON_BIN="$(find_python || true)"
            if [ -n "$PYTHON_BIN" ]; then
              return 0
            fi
          fi

          PKG_PATH="$BASE/python-$PYTHON_VERSION-macos11.pkg"
          info "正在下载 Python 官方安装包..."
          if curl -L --fail "$PYTHON_PKG_URL" -o "$PKG_PATH"; then
            info "正在安装 Python。macOS 可能会要求输入电脑密码，这是系统安装器的正常提示。"
            if sudo installer -pkg "$PKG_PATH" -target /; then
              PYTHON_BIN="$(find_python || true)"
              if [ -n "$PYTHON_BIN" ]; then
                return 0
              fi
            fi
          fi
          return 1
        }

        install_python_requirements() {
          if [ ! -x "$VENV/bin/python" ]; then
            info "Python 虚拟环境未创建成功：$VENV/bin/python"
            return 1
          fi
          for index_url in $PIP_INDEX_URLS; do
            [ -z "$index_url" ] && continue
            info "正在安装 Python 依赖：$index_url"
            if "$VENV/bin/python" -m pip install --disable-pip-version-check -i "$index_url" -r "$APP_DIR/requirements-agent.txt"; then
              return 0
            fi
            info "该源安装失败，正在尝试下一个源..."
          done
          return 1
        }

        create_virtual_environment() {
          rm -rf "$VENV"
          if ! "$PYTHON_BIN" -m venv "$VENV"; then
            info "Python 虚拟环境创建失败，请重新安装 Python 后再试。"
            return 1
          fi
          if [ ! -x "$VENV/bin/python" ]; then
            info "Python 虚拟环境未创建成功：$VENV/bin/python"
            return 1
          fi
          if ! "$VENV/bin/python" -m pip --version >/dev/null 2>&1; then
            "$VENV/bin/python" -m ensurepip --upgrade || true
          fi
          "$VENV/bin/python" -m pip --version >/dev/null 2>&1
        }

        install_playwright_chromium() {
          info "正在安装后台浏览器组件..."
          if "$VENV/bin/python" -m playwright install chromium; then
            return 0
          fi
          for host_url in $PLAYWRIGHT_DOWNLOAD_HOSTS; do
            [ -z "$host_url" ] && continue
            info "正在尝试浏览器组件镜像：$host_url"
            if PLAYWRIGHT_DOWNLOAD_HOST="$host_url" "$VENV/bin/python" -m playwright install chromium; then
              return 0
            fi
          done
          return 1
        }

        local_ffmpeg_bin() {
          if [ -x "$FFMPEG_BIN/ffmpeg" ] && [ -x "$FFMPEG_BIN/ffprobe" ]; then
            printf "%s\n" "$FFMPEG_BIN"
            return 0
          fi
          return 1
        }

        ffmpeg_available() {
          if local_ffmpeg_bin >/dev/null 2>&1; then
            return 0
          fi
          command -v ffmpeg >/dev/null 2>&1 && command -v ffprobe >/dev/null 2>&1
        }

        install_ffmpeg_dependency() {
          if ffmpeg_available; then
            info "FFmpeg 已可用。"
            return 0
          fi
          info "未检测到 FFmpeg，正在尝试安装本地 FFmpeg 组件..."
          if command -v brew >/dev/null 2>&1; then
            info "正在使用 Homebrew 安装 FFmpeg..."
            brew install ffmpeg || true
            if ffmpeg_available; then
              return 0
            fi
          fi

          mkdir -p "$FFMPEG_BIN"
          FFMPEG_ZIP="$BASE/ffmpeg.zip"
          FFPROBE_ZIP="$BASE/ffprobe.zip"
          TMP_FFMPEG="$BASE/ffmpeg-unzip"
          rm -rf "$TMP_FFMPEG"
          mkdir -p "$TMP_FFMPEG"
          if curl -L --fail "$FFMPEG_ZIP_URL" -o "$FFMPEG_ZIP" && curl -L --fail "$FFPROBE_ZIP_URL" -o "$FFPROBE_ZIP"; then
            unzip -q "$FFMPEG_ZIP" -d "$TMP_FFMPEG"
            unzip -q "$FFPROBE_ZIP" -d "$TMP_FFMPEG"
            FFMPEG_FILE="$(find "$TMP_FFMPEG" -type f -name ffmpeg | head -n 1)"
            FFPROBE_FILE="$(find "$TMP_FFMPEG" -type f -name ffprobe | head -n 1)"
            if [ -n "$FFMPEG_FILE" ] && [ -n "$FFPROBE_FILE" ]; then
              cp "$FFMPEG_FILE" "$FFMPEG_BIN/ffmpeg"
              cp "$FFPROBE_FILE" "$FFMPEG_BIN/ffprobe"
              chmod +x "$FFMPEG_BIN/ffmpeg" "$FFMPEG_BIN/ffprobe"
            fi
            rm -rf "$TMP_FFMPEG"
          fi
          if ffmpeg_available; then
            info "FFmpeg 已准备好。"
            return 0
          fi
          info "FFmpeg 自动安装失败。图片和单文件视频仍可使用，部分高清合并可能失败。"
          return 1
        }

        wait_for_agent() {
          for attempt in $(seq 1 45); do
            if curl -fsS "http://127.0.0.1:17890/api/health" >/dev/null 2>&1 && curl -fsS "$CONTROL_URL" | grep -q "视频/图片下载工具"; then
              return 0
            fi
            sleep 1
          done
          return 1
        }

        finish() {
          printf "\n安装窗口可以关闭了。\n"
          printf "如果浏览器没有自动打开，请访问：%s\n" "$CONTROL_URL"
          read -r -n 1 -s -p "按任意键关闭..." || true
          printf "\n"
        }
        trap finish EXIT

        info "正在安装本地下载助手..."
        if ! command -v curl >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1; then
          info "系统缺少 curl 或 unzip，无法继续安装。"
          exit 1
        fi
        mkdir -p "$BASE" "$LOG_DIR" "$TOOLS_DIR" "$HOME/Library/LaunchAgents"

        PYTHON_BIN="$(find_python || true)"
        if [ -z "$PYTHON_BIN" ]; then
          if ! install_python_dependency; then
            info "Python 3.9+ 无法自动安装。请先安装 Python 3.9 或更新版本后，再运行安装器。"
            info "安装器不会自动跳转网页；如需手动安装，请访问：https://www.python.org/downloads/macos/"
            exit 1
          fi
        fi
        PYTHON_BIN="$(find_python || true)"
        if [ -z "$PYTHON_BIN" ]; then
          info "Python 3.9+ 仍不可用。请手动安装 Python 后重试。"
          info "手动安装地址：https://www.python.org/downloads/macos/"
          exit 1
        fi

        mkdir -p "$BASE" "$APP_DIR" "$LOG_DIR" "$TOOLS_DIR" "$HOME/Library/LaunchAgents"
        if [ -f "$BUNDLED_ZIP" ]; then
          info "正在使用安装包内置组件..."
          cp "$BUNDLED_ZIP" "$ZIP_PATH"
        else
          if [ -z "$AGENT_URL" ]; then
            info "安装包缺少内置组件，且当前构建没有配置远程下载地址。请重新下载安装包。"
            exit 1
          fi
          info "正在下载本地组件..."
          curl -L --fail "$AGENT_URL" -o "$ZIP_PATH"
        fi
        ACTUAL_SHA256="$(shasum -a 256 "$ZIP_PATH" | awk '{print $1}')"
        if [ "$ACTUAL_SHA256" != "$EXPECTED_SHA256" ]; then
          info "安装包校验失败，请重新下载。"
          exit 1
        fi

        RUNTIME_BACKUP="$BASE/runtime-backup-$(date +%s)"
        if [ -d "$APP_DIR/.runtime" ]; then
          cp -R "$APP_DIR/.runtime" "$RUNTIME_BACKUP"
        fi
        rm -rf "$APP_DIR"
        mkdir -p "$APP_DIR"
        unzip -q "$ZIP_PATH" -d "$APP_DIR"
        if [ -d "$RUNTIME_BACKUP" ]; then
          rm -rf "$APP_DIR/.runtime"
          mv "$RUNTIME_BACKUP" "$APP_DIR/.runtime"
        fi

        info "正在准备 Python 环境..."
        if ! create_virtual_environment; then
          exit 1
        fi
        if ! install_python_requirements; then
          info "Python 依赖安装失败。请检查网络后重试；如果官方源不可用，安装器会自动尝试国内镜像。"
          exit 1
        fi
        if ! install_playwright_chromium; then
          info "后台浏览器组件下载失败。多数平台仍可解析；抖音等需要浏览器辅助的平台可能暂时不可用，可换网络后重新运行安装器。"
        fi

        install_ffmpeg_dependency || true

        TOKEN="$("$VENV/bin/python" - "$APP_DIR" <<'PY'
import json
import secrets
import sys
import time
from pathlib import Path

app_dir = Path(sys.argv[1])
token_file = app_dir / ".runtime" / "agent-token.json"
token_file.parent.mkdir(parents=True, exist_ok=True)
token = ""
if token_file.exists():
    try:
        token = json.loads(token_file.read_text(encoding="utf-8")).get("token", "")
    except Exception:
        token = ""
if not token:
    token = secrets.token_urlsafe(32)
    token_file.write_text(json.dumps({"token": token, "created_at": int(time.time())}, ensure_ascii=False, indent=2), encoding="utf-8")
print(token)
PY
        )"

        "$VENV/bin/python" - "$APP_DIR" "$UPDATE_MANIFEST_URL" "$ALLOWED_ORIGIN" <<'PY'
import json
import sys
from pathlib import Path

app_dir = Path(sys.argv[1])
manifest_url = sys.argv[2].strip()
allowed_origin = sys.argv[3].strip().rstrip("/")
runtime_dir = app_dir / ".runtime"
runtime_dir.mkdir(parents=True, exist_ok=True)
data = {"update_manifest_url": manifest_url}
if allowed_origin:
    data["allowed_origins"] = [allowed_origin]
else:
    data["allowed_origins"] = []
(runtime_dir / "install-source.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
PY

        cat > "$PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>app.video-downloader.agent</string>
  <key>ProgramArguments</key>
  <array>
    <string>$VENV/bin/python</string>
    <string>-m</string>
    <string>local_agent.server</string>
  </array>
  <key>WorkingDirectory</key>
  <string>$APP_DIR</string>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>$LOG_DIR/agent.log</string>
  <key>StandardErrorPath</key>
  <string>$LOG_DIR/agent.err.log</string>
  <key>EnvironmentVariables</key>
  <dict>
  <key>PATH</key>
    <string>$FFMPEG_BIN:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
  </dict>
</dict>
</plist>
PLIST

        info "正在启动本地助手..."
        USER_ID="$(id -u)"
        launchctl bootout "gui/$USER_ID" "$PLIST" >/dev/null 2>&1 || true
        pkill -f "local_agent.server" >/dev/null 2>&1 || true
        launchctl enable "gui/$USER_ID/app.video-downloader.agent" >/dev/null 2>&1 || true
        launchctl bootstrap "gui/$USER_ID" "$PLIST"
        launchctl enable "gui/$USER_ID/app.video-downloader.agent" >/dev/null 2>&1 || true

        if wait_for_agent; then
          info "本地助手已启动。正在打开本机控制台..."
        else
          info "本地助手启动较慢，请稍后打开本机控制台并点击重新检测。"
        fi
        open "$CONTROL_URL?install=$(date +%s)#agentToken=$TOKEN"
