#!/bin/bash
set -u

APP_NAME="VideoDownloaderAgent"
BASE="$HOME/Library/Application Support/$APP_NAME"
PLIST="$HOME/Library/LaunchAgents/app.video-downloader.agent.plist"
CONTROL_URL="http://127.0.0.1:17890/"

info() {
  printf "\n%s\n" "$1"
}

finish() {
  printf "\n卸载窗口可以关闭了。\n"
  read -r -n 1 -s -p "按任意键关闭..." || true
  printf "\n"
}
trap finish EXIT

info "正在卸载本地下载助手..."
info "这只会删除本地助手程序、启动项、token、设置和临时缓存，不会删除你已经下载的视频或图片文件。"

USER_ID="$(id -u)"
launchctl bootout "gui/$USER_ID" "$PLIST" >/dev/null 2>&1 || true
launchctl disable "gui/$USER_ID/app.video-downloader.agent" >/dev/null 2>&1 || true
pkill -f "local_agent.server" >/dev/null 2>&1 || true
rm -f "$PLIST"
rm -rf "$BASE"

if curl -fsS "$CONTROL_URL/api/health" >/dev/null 2>&1; then
  info "本地助手仍在运行，请重启电脑后再试。"
else
  info "本地助手已卸载。需要再次使用时，重新运行安装脚本即可。"
fi
