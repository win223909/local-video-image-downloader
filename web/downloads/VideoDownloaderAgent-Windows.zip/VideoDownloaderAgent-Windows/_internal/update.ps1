﻿$ErrorActionPreference = "Stop"

$Base = Join-Path $env:LOCALAPPDATA "VideoDownloaderAgent"
$AppDir = Join-Path $Base "app"
$VenvPython = Join-Path $Base ".venv\Scripts\python.exe"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Updater = Join-Path $ScriptDir "updater.py"
if (-not (Test-Path $Updater)) {
  $Updater = Join-Path $AppDir "local_agent\updater.py"
}
$ControlUrl = "http://127.0.0.1:17890/"
$ManifestUrl = "https://download.k666.xyz/downloads/update.json"

function Info($Message) {
  Write-Host ""
  Write-Host $Message
}

function Open-ControlPage([string]$Url) {
  try {
    Start-Process -FilePath "cmd.exe" -ArgumentList "/c", "start", "`"`"", "`"$Url`"" -WindowStyle Hidden | Out-Null
    return $true
  } catch {
    Info "Could not open the control page automatically. Please open this URL manually:"
    Info $Url
    return $false
  }
}

Info "Updating local downloader agent..."
if (-not (Test-Path $VenvPython) -or -not (Test-Path $AppDir)) {
  Info "No installed local agent was found. Please run 01-INSTALL first."
  Read-Host "Press Enter to close"
  exit 1
}
if (-not (Test-Path $Updater)) {
  Info "Update component is missing. Please download the installer again."
  Read-Host "Press Enter to close"
  exit 1
}

& $VenvPython $Updater --app-dir $AppDir --manifest-url $ManifestUrl --restart
Info "Update command finished. Opening control page..."
$UpdatedTs = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$ControlPageUrl = "{0}?updated={1}" -f $ControlUrl, $UpdatedTs
Open-ControlPage $ControlPageUrl | Out-Null
Read-Host "Update finished. Press Enter to close"
