﻿$ErrorActionPreference = "Stop"

$Base = Join-Path $env:LOCALAPPDATA "VideoDownloaderAgent"
$AppDir = Join-Path $Base "app"
$Venv = Join-Path $Base ".venv"
$Logs = Join-Path $Base "logs"
$ToolsDir = Join-Path $Base "tools"
$FfmpegDir = Join-Path $ToolsDir "ffmpeg"
$ZipPath = Join-Path $Base "agent-source.zip"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$BundledZip = Join-Path $ScriptDir "agent-source.zip"
if (-not (Test-Path $BundledZip)) {
  $BundledZip = Join-Path (Split-Path -Parent $ScriptDir) "_internal\agent-source.zip"
}
$RunScript = Join-Path $Base "run-agent.ps1"
$AgentUrl = "https://download.k666.xyz/downloads/agent-source.zip"
$ControlUrl = "http://127.0.0.1:17890/"
$ManifestUrl = "https://download.k666.xyz/downloads/update.json"
$AllowedOrigin = "https://download.k666.xyz"
$ExpectedSha256 = "360c62be7a2076c2f85fab04673924eee530ca1a971fc747a90c99b60c054d60"
$PythonVersion = "3.12.10"
$PythonInstallerUrls = @{
  "AMD64" = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe"
  "ARM64" = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-arm64.exe"
  "X86" = "https://www.python.org/ftp/python/3.12.10/python-3.12.10.exe"
}
$FfmpegZipUrl = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
if ($env:PIP_INDEX_URLS) {
  $PipIndexUrls = $env:PIP_INDEX_URLS -split "\s+" | Where-Object { $_ }
} elseif ($env:PIP_INDEX_URL) {
  $PipIndexUrls = @($env:PIP_INDEX_URL, "https://mirrors.aliyun.com/pypi/simple", "https://pypi.tuna.tsinghua.edu.cn/simple", "https://pypi.doubanio.com/simple")
} else {
  $PipIndexUrls = @("https://pypi.org/simple", "https://mirrors.aliyun.com/pypi/simple", "https://pypi.tuna.tsinghua.edu.cn/simple", "https://pypi.doubanio.com/simple")
}
if ($env:PLAYWRIGHT_DOWNLOAD_HOSTS) {
  $PlaywrightDownloadHosts = $env:PLAYWRIGHT_DOWNLOAD_HOSTS -split "\s+" | Where-Object { $_ }
} elseif ($env:PLAYWRIGHT_DOWNLOAD_HOST) {
  $PlaywrightDownloadHosts = @($env:PLAYWRIGHT_DOWNLOAD_HOST, "https://npmmirror.com/mirrors/playwright")
} else {
  $PlaywrightDownloadHosts = @("https://npmmirror.com/mirrors/playwright")
}
$StartupRegPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$StartupRegName = "Video Downloader Agent"

function Info($Message) {
  Write-Host ""
  Write-Host $Message
}

function Open-ControlPage([string]$Url) {
  try {
    Start-Process -FilePath "cmd.exe" -ArgumentList "/c", "start", "`"`"", "`"$Url`"" -WindowStyle Hidden | Out-Null
    return $true
  } catch {
    Info "Could not open the control page automatically. Please open this URL manually:"
    Info $Url
    return $false
  }
}

function Get-WindowsArchitecture {
  $Arch = $env:PROCESSOR_ARCHITEW6432
  if ([string]::IsNullOrWhiteSpace($Arch)) {
    $Arch = $env:PROCESSOR_ARCHITECTURE
  }
  if ($Arch -eq "ARM64") { return "ARM64" }
  if ([Environment]::Is64BitOperatingSystem) { return "AMD64" }
  return "X86"
}

function Refresh-ProcessPath {
  $MachinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
  $UserPath = [Environment]::GetEnvironmentVariable("Path", "User")
  $KnownPythonPaths = @(
    "$env:LOCALAPPDATA\Programs\Python\Python314",
    "$env:LOCALAPPDATA\Programs\Python\Python314\Scripts",
    "$env:LOCALAPPDATA\Programs\Python\Python313",
    "$env:LOCALAPPDATA\Programs\Python\Python313\Scripts",
    "$env:LOCALAPPDATA\Programs\Python\Python312",
    "$env:LOCALAPPDATA\Programs\Python\Python312\Scripts",
    "$env:LOCALAPPDATA\Programs\Python\Python311",
    "$env:LOCALAPPDATA\Programs\Python\Python311\Scripts",
    "$env:ProgramFiles\Python314",
    "$env:ProgramFiles\Python314\Scripts",
    "$env:ProgramFiles\Python313",
    "$env:ProgramFiles\Python313\Scripts",
    "$env:ProgramFiles\Python312",
    "$env:ProgramFiles\Python312\Scripts",
    "$env:ProgramFiles\Python311",
    "$env:ProgramFiles\Python311\Scripts"
  ) | Where-Object { $_ -and (Test-Path $_) }
  $PathParts = @($MachinePath, $UserPath, ($KnownPythonPaths -join ";"), $env:PATH) | Where-Object { $_ }
  $env:PATH = ($PathParts -join ";")
}

function Download-File([string]$Url, [string]$OutFile) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing
}

function Invoke-PythonCandidate([string[]]$Candidate, [string[]]$ArgsList, [switch]$Quiet) {
  if (-not $Candidate -or $Candidate.Length -lt 1) { return $false }
  $Exe = $Candidate[0]
  $RunArgs = @()
  if ($Candidate.Length -gt 1) {
    $RunArgs += $Candidate[1..($Candidate.Length - 1)]
  }
  $RunArgs += $ArgsList
  try {
    $CommandOutput = & $Exe @RunArgs 2>&1
    $ExitCode = $LASTEXITCODE
  } catch {
    if (-not $Quiet) { Write-Host $_ }
    return $false
  }
  if (-not $Quiet -and $CommandOutput) {
    $CommandOutput | ForEach-Object { Write-Host $_ }
  }
  return ($ExitCode -eq 0)
}

function Test-PythonCandidate([string[]]$Candidate) {
  if (-not $Candidate -or $Candidate.Length -lt 1) { return $false }
  if (-not (Test-Path $Candidate[0]) -and -not (Get-Command $Candidate[0] -ErrorAction SilentlyContinue)) { return $false }
  return (Invoke-PythonCandidate -Candidate $Candidate -ArgsList @("-c", "import sys, venv; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)") -Quiet)
}

function Find-Python {
  Refresh-ProcessPath
  $Candidates = @(
    ,@("py", "-3.12")
    ,@("py", "-3.11")
    ,@("py", "-3")
    ,@("python")
    ,@("python3")
    ,@("$env:LOCALAPPDATA\Programs\Python\Python314\python.exe")
    ,@("$env:LOCALAPPDATA\Programs\Python\Python313\python.exe")
    ,@("$env:LOCALAPPDATA\Programs\Python\Python312\python.exe")
    ,@("$env:LOCALAPPDATA\Programs\Python\Python311\python.exe")
    ,@("$env:ProgramFiles\Python314\python.exe")
    ,@("$env:ProgramFiles\Python313\python.exe")
    ,@("$env:ProgramFiles\Python312\python.exe")
    ,@("$env:ProgramFiles\Python311\python.exe")
  )
  foreach ($Candidate in $Candidates) {
    if (Test-PythonCandidate -Candidate $Candidate) {
      return $Candidate
    }
  }
  return $null
}

function Install-PythonDependency {
  Info "Python 3.11+ was not found. Installing Python first..."
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    Info "Trying Windows Package Manager: Python 3.12"
    winget install -e --id Python.Python.3.12 --silent --scope user --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
      winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    }
    $script:Python = @(Find-Python)
    if ($script:Python) { return $true }
  }

  $Arch = Get-WindowsArchitecture
  $InstallerUrl = $PythonInstallerUrls[$Arch]
  if (-not $InstallerUrl) { $InstallerUrl = $PythonInstallerUrls["AMD64"] }
  $InstallerPath = Join-Path $Base ("python-" + $PythonVersion + "-" + $Arch + ".exe")
  try {
    Info "Downloading Python installer..."
    Download-File $InstallerUrl $InstallerPath
    Info "Installing Python. This may take a few minutes..."
    $InstallArgs = "/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_pip=1 Include_tcltk=0 Include_test=0 SimpleInstall=1"
    $Process = Start-Process -FilePath $InstallerPath -ArgumentList $InstallArgs -Wait -PassThru
    if ($Process.ExitCode -ne 0) {
      Info "Python installer exited with code $($Process.ExitCode)."
    }
  } catch {
    Info "Automatic Python download or installation failed."
    Write-Host $_
  }
  $script:Python = @(Find-Python)
  return [bool]$script:Python
}

function Invoke-BasePython([string[]]$ArgsList) {
  return (Invoke-PythonCandidate -Candidate $Python -ArgsList $ArgsList)
}

function New-VirtualEnvironment {
  if (Test-Path $Venv) {
    Remove-Item $Venv -Recurse -Force -ErrorAction SilentlyContinue
  }
  if (-not (Invoke-BasePython -ArgsList @("-m", "venv", $Venv))) {
    Info "Could not create the Python virtual environment. Please repair or reinstall Python 3.11+ and run this installer again."
    return $false
  }
  $script:VenvPython = Join-Path $Venv "Scripts\python.exe"
  $script:VenvPythonw = Join-Path $Venv "Scripts\pythonw.exe"
  if (-not (Test-Path $script:VenvPython)) {
    Info "The virtual environment was not created correctly: $script:VenvPython"
    Info "Please repair or reinstall Python 3.11+ and run this installer again."
    return $false
  }
  & $script:VenvPython -m pip --version *> $null
  if ($LASTEXITCODE -ne 0) {
    & $script:VenvPython -m ensurepip --upgrade
    & $script:VenvPython -m pip --version *> $null
    if ($LASTEXITCODE -ne 0) {
      Info "pip is not available in the Python virtual environment. Please repair Python and run this installer again."
      return $false
    }
  }
  return $true
}

function Install-PythonRequirements {
  $Requirements = Join-Path $AppDir "requirements-agent.txt"
  if (-not (Test-Path $VenvPython)) {
    Info "The virtual environment Python file is missing: $VenvPython"
    return $false
  }
  foreach ($IndexUrl in $PipIndexUrls) {
    if ([string]::IsNullOrWhiteSpace($IndexUrl)) { continue }
    Info "Installing Python dependencies from: $IndexUrl"
    & $VenvPython -m pip install --disable-pip-version-check -i $IndexUrl -r $Requirements
    if ($LASTEXITCODE -eq 0) { return $true }
    Info "This source failed. Trying the next source..."
  }
  return $false
}

function Install-PlaywrightChromium {
  if (-not (Test-Path $VenvPython)) {
    Info "The virtual environment Python file is missing: $VenvPython"
    return $false
  }
  Info "Installing browser component..."
  & $VenvPython -m playwright install chromium
  if ($LASTEXITCODE -eq 0) { return $true }
  foreach ($HostUrl in $PlaywrightDownloadHosts) {
    if ([string]::IsNullOrWhiteSpace($HostUrl)) { continue }
    Info "Trying browser component mirror: $HostUrl"
    $OldHost = $env:PLAYWRIGHT_DOWNLOAD_HOST
    $env:PLAYWRIGHT_DOWNLOAD_HOST = $HostUrl
    & $VenvPython -m playwright install chromium
    if ($OldHost) {
      $env:PLAYWRIGHT_DOWNLOAD_HOST = $OldHost
    } else {
      Remove-Item Env:PLAYWRIGHT_DOWNLOAD_HOST -ErrorAction SilentlyContinue
    }
    if ($LASTEXITCODE -eq 0) { return $true }
  }
  return $false
}

function Get-LocalFfmpegBin {
  $Candidate = Join-Path $FfmpegDir "bin"
  if ((Test-Path (Join-Path $Candidate "ffmpeg.exe")) -and (Test-Path (Join-Path $Candidate "ffprobe.exe"))) {
    return $Candidate
  }
  return ""
}

function Find-FFmpeg {
  $LocalBin = Get-LocalFfmpegBin
  if ($LocalBin) { return $LocalBin }
  if ((Get-Command ffmpeg -ErrorAction SilentlyContinue) -and (Get-Command ffprobe -ErrorAction SilentlyContinue)) {
    return "system"
  }
  return ""
}

function Install-FFmpegDependency {
  $Existing = Find-FFmpeg
  if ($Existing) {
    Info "FFmpeg is available."
    return $true
  }

  Info "FFmpeg was not found. Installing FFmpeg for video merging..."
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    Info "Trying Windows Package Manager: FFmpeg"
    winget install -e --id Gyan.FFmpeg --silent --accept-package-agreements --accept-source-agreements
    Refresh-ProcessPath
    $Existing = Find-FFmpeg
    if ($Existing) { return $true }
  }

  try {
    $FfmpegZip = Join-Path $Base "ffmpeg-release-essentials.zip"
    $ExtractDir = Join-Path $ToolsDir "ffmpeg-extract"
    Info "Downloading FFmpeg local package..."
    New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
    Download-File $FfmpegZipUrl $FfmpegZip
    if (Test-Path $ExtractDir) { Remove-Item $ExtractDir -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Force -Path $ExtractDir | Out-Null
    Expand-Archive -Path $FfmpegZip -DestinationPath $ExtractDir -Force
    $FfmpegExe = Get-ChildItem -Path $ExtractDir -Recurse -Filter "ffmpeg.exe" | Select-Object -First 1
    if ($FfmpegExe) {
      $PackageRoot = Split-Path -Parent (Split-Path -Parent $FfmpegExe.FullName)
      if (Test-Path $FfmpegDir) { Remove-Item $FfmpegDir -Recurse -Force -ErrorAction SilentlyContinue }
      Move-Item $PackageRoot $FfmpegDir -Force
      Remove-Item $ExtractDir -Recurse -Force -ErrorAction SilentlyContinue
    }
  } catch {
    Info "Automatic FFmpeg installation failed. Images and single-file videos can still work."
    Write-Host $_
  }
  $Existing = Find-FFmpeg
  if ($Existing) {
    Info "FFmpeg is ready."
    return $true
  }
  Info "FFmpeg is still unavailable. Some HD video merges may fail until FFmpeg is installed."
  return $false
}

function Wait-AgentReady {
  for ($Index = 0; $Index -lt 45; $Index++) {
    try {
      Invoke-RestMethod -Uri "http://127.0.0.1:17890/api/health" -TimeoutSec 2 | Out-Null
      $HomePage = Invoke-WebRequest -Uri $ControlUrl -UseBasicParsing -TimeoutSec 2
      if ($HomePage.Content -like "*sourceInput*" -or $HomePage.Content -like "*downloadButton*") {
        return $true
      }
    } catch {}
    Start-Sleep -Seconds 1
  }
  return $false
}

Info "Installing local downloader agent..."
$Python = @(Find-Python)
if (-not $Python) {
  if (-not (Install-PythonDependency)) {
    Info "Python 3.11+ could not be installed automatically."
    Info "Please install Python 3.11 or newer, then run this installer again."
    Start-Process "https://www.python.org/downloads/windows/"
    Read-Host "Press Enter to close"
    exit 1
  }
}
if (-not $Python) {
  Info "Python 3 was not found. Please install Python 3.11 or newer, then run this installer again."
  Start-Process "https://www.python.org/downloads/windows/"
  Read-Host "Press Enter to close"
  exit 1
}

New-Item -ItemType Directory -Force -Path $Base, $AppDir, $Logs | Out-Null
if (Test-Path $BundledZip) {
  Info "Using bundled agent files..."
  Copy-Item $BundledZip $ZipPath -Force
} else {
  if (-not $AgentUrl) {
    Info "Bundled agent files are missing and this build has no remote download URL. Please download the installer again."
    Read-Host "Press Enter to close"
    exit 1
  }
  Info "Downloading agent files..."
  Invoke-WebRequest -Uri $AgentUrl -OutFile $ZipPath
}
$ActualSha256 = (Get-FileHash -Algorithm SHA256 $ZipPath).Hash.ToLowerInvariant()
if ($ActualSha256 -ne $ExpectedSha256) {
  Info "Package verification failed. Please download the installer again."
  Read-Host "Press Enter to close"
  exit 1
}

$RuntimeBackup = Join-Path $Base ("runtime-backup-" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
$ExistingRuntime = Join-Path $AppDir ".runtime"
if (Test-Path $ExistingRuntime) {
  Copy-Item $ExistingRuntime $RuntimeBackup -Recurse -Force
}
if (Test-Path $AppDir) { Remove-Item $AppDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $AppDir | Out-Null
Expand-Archive -Path $ZipPath -DestinationPath $AppDir -Force
if (Test-Path $RuntimeBackup) {
  $NewRuntime = Join-Path $AppDir ".runtime"
  if (Test-Path $NewRuntime) { Remove-Item $NewRuntime -Recurse -Force }
  Move-Item $RuntimeBackup $NewRuntime -Force
}

Info "Preparing Python environment..."
if (-not (New-VirtualEnvironment)) {
  Read-Host "Press Enter to close"
  exit 1
}
if (-not (Install-PythonRequirements)) {
  Info "Python dependency installation failed. Please check the network and try again."
  Read-Host "Press Enter to close"
  exit 1
}
if (-not (Install-PlaywrightChromium)) {
  Info "Browser component installation failed. Many platforms still work; Douyin-like sites may need a later retry."
}

Install-FFmpegDependency | Out-Null

$RuntimeDir = Join-Path $AppDir ".runtime"
$TokenFile = Join-Path $RuntimeDir "agent-token.json"
New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null
$Token = ""
if (Test-Path $TokenFile) {
  try { $Token = (Get-Content $TokenFile -Raw | ConvertFrom-Json).token } catch { $Token = "" }
}
if (-not $Token) {
  $Bytes = New-Object byte[] 32
  [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($Bytes)
  $Token = [Convert]::ToBase64String($Bytes).TrimEnd("=").Replace("+", "-").Replace("/", "_")
  @{ token = $Token; created_at = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() } | ConvertTo-Json | Set-Content -Encoding UTF8 $TokenFile
}
$InstallSourceFile = Join-Path $RuntimeDir "install-source.json"
$AllowedOrigins = @()
if ($AllowedOrigin) { $AllowedOrigins = @($AllowedOrigin) }
@{ update_manifest_url = $ManifestUrl; allowed_origins = $AllowedOrigins } | ConvertTo-Json | Set-Content -Encoding UTF8 $InstallSourceFile

$RunScriptFfmpegLine = ""
$LocalFfmpegBin = Get-LocalFfmpegBin
if ($LocalFfmpegBin) {
  $RunScriptFfmpegLine = '$env:PATH = "' + $LocalFfmpegBin + ';$env:PATH"'
}
@"
Set-Location "$AppDir"
$RunScriptFfmpegLine
& "$VenvPython" -m local_agent.server *> "$Logs\agent.log"
"@ | Set-Content -Encoding UTF8 $RunScript

Info "Setting startup entry..."
Get-Process | Where-Object { $_.Path -eq $VenvPython -or $_.Path -eq $VenvPythonw } | Stop-Process -Force -ErrorAction SilentlyContinue
$RunCommand = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$RunScript`""
try {
  New-Item -Path $StartupRegPath -Force | Out-Null
  New-ItemProperty -Path $StartupRegPath -Name $StartupRegName -PropertyType String -Value $RunCommand -Force | Out-Null
  Info "Startup entry was added."
} catch {
  Info "Startup entry could not be added. The agent will still start now."
}
Start-Process -FilePath "powershell.exe" -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$RunScript`"" -WorkingDirectory $AppDir

Info "Starting local agent..."
if (Wait-AgentReady) {
  Info "Local agent is ready. Opening control page..."
} else {
  Info "Local agent is starting slowly. If the page is not connected yet, wait a few seconds and retry."
}
$InstallTs = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$ControlPageUrl = "{0}?install={1}#agentToken={2}" -f $ControlUrl, $InstallTs, $Token
Open-ControlPage $ControlPageUrl | Out-Null
Read-Host "Install finished. Press Enter to close"
