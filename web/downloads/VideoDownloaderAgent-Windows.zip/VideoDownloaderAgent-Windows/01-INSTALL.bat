@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
title Video Downloader Agent - Install

set "INSTALL_DIR=%~dp0"
pushd "%INSTALL_DIR%" >nul 2>nul
if errorlevel 1 (
  echo Cannot enter installer folder: %INSTALL_DIR%
  echo.
  echo If you are using Parallels, C:\Mac\Home\Desktop is the Mac shared desktop.
  echo Please copy this extracted folder to C:\Users\your-Windows-name\Desktop and run this script again.
  echo.
  pause
  exit /b 1
)

set "SCRIPT=%CD%\_internal\install.ps1"
if not exist "%SCRIPT%" (
  echo Missing Install component: %SCRIPT%
  echo.
  echo Please right-click the downloaded zip file and choose Extract All first.
  echo Then open the extracted folder and double-click this script again.
  echo Do not run this script directly inside the zip preview window.
  echo.
  pause
  exit /b 1
)

echo Starting Install...
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%EXIT_CODE%"=="0" (
  echo Install did not finish. Error code: %EXIT_CODE%
  echo Please take a screenshot of the messages above.
) else (
  echo Install script finished.
)
echo.
pause
popd >nul 2>nul
exit /b %EXIT_CODE%
